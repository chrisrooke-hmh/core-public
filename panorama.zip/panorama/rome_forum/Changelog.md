Changelog:

index.html

- added Google font stylesheet
- added button element to #description

style.css

- added lots of styling

panoramic.js

- lines 5-6, changed canvas size to viewport size (may need to be reviewed!)

Known issues

- appearance of empty panel on load
- close button not active
- Panorama not resizing on viewport size change
